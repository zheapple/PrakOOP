/**
 * ICommandAction.java
 * [Jelaskan kegunaan interface ini]
 * 
 * @author 18223105 Zheannetta Apple
 */

public interface ICommandAction {
    void execute();
    void undo();
}