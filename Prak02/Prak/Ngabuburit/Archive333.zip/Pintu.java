public class Pintu {
    public void open() {
        System.out.println("Pintu dibuka!");
    }

    public void close() {
        System.out.println("Pintu ditutup!");
    }
}
