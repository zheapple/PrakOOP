public class Laptop {
    public void turnOn() {
        System.out.println("Laptop dinyalakan!");
    }

    public void turnOff() {
        System.out.println("Laptop dimatikan!");
    }

    public void use() {
        System.out.println("Menggunakan laptop untuk ngoding gacor");
    }
}
