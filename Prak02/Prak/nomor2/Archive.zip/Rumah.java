public class Rumah {
    public void goOut() {
        System.out.println("Pergi ke luar rumah!");
    }

    public void goIn() {
        System.out.println("Masuk lagi ke rumah!");
    }

    public void run() {
        System.out.println("Berlari di gasibu sejauh 10 km!");
    }

    public void buy() {
        System.out.println("Membeli kolak!");
    }
}
